#ifndef WYSZUKIWANIE
#define WYSZUKIWANIE

#include"Operacje_lista.h"
#include"Edycja.h"


void find_menu_to_print(Album *lista);






#endif // WYSZUKIWANIE
