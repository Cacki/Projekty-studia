#ifndef EXPORT_CSV
#define EXPORT_CSV

#include"Operacje_lista.h"

void Export_Csv(char *filename, Album *lista);

#endif // EXPORT_CSV
