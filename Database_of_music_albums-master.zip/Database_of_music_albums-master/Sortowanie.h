#ifndef SORTOWANIE
#define SORTOWANIE

#include"Operacje_lista.h"

void insert_sorted_ascending(Album **head, Album *new_node, int wybor);
void insert_sorted_descending(Album **head, Album *new_node, int wybor);
void sort_list(Album **head);





#endif // SORTOWANIE
