#ifndef WCZYT_ODCZYT_LISTA
#define WCZYT_ODCZYT_LISTA

#include"Operacje_lista.h"

void do_programu(Album **lista);
void do_pliku(Album *lista);



#endif // WCZYT_ODCZYT_LISTA
